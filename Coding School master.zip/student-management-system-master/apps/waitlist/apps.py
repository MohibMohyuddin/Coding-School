from django.apps import AppConfig


class WaitlistConfig(AppConfig):
    name = 'waitlist'
